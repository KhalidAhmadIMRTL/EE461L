package com.example.homeworkgeocodingapp;

import androidx.fragment.app.FragmentActivity;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import org.json.JSONObject;
import org.json.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
    //Variable
    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    public void setPolicy(StrictMode.ThreadPolicy policy1) {
        this.policy = policy1;
    }

    private GoogleMap mMap;
    private EditText searchText;
    public Address address;
    Button mButton;
    TextView weatherInfo;
    Toast toast;
    String darkSkyKey;
    String forecastURL;
    JSONObject darkSky;
    //OnCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPolicy(policy);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        darkSkyKey = "d3bb773e20276985f255ce69b8138ac3";
        forecastURL = "https://api.darksky.net/forecast/";
        init();
    }
    //Init method
    private void init(){
        mButton = (Button)findViewById(R.id.button1);
        mButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                geoLocate();
            }
        });
    }
    //Geolocate
    private void geoLocate(){
        searchText  = (EditText) findViewById(R.id.input_search);
        String searchString = searchText.getText().toString();

        //Create a geocoder
        Geocoder geocoder = new Geocoder(MapsActivity.this);
        List<Address> list = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString,1);
        }catch (IOException e){
        }
        if(list.size() > 0 ){
            address = list.get(0);
            mMap.addMarker(new MarkerOptions().position(new LatLng(address.getLatitude(),address.getLongitude())));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(address.getLatitude(),address.getLongitude())));
            try{
                getWeather(address);
            } catch (Exception E){

            }
        }
    }

    public void getWeather(Address address) throws Exception{

        final Address address1 = address;

        Thread thread = new Thread(new Runnable(){
            public void run(){
                try{


                    forecastURL = "https://api.darksky.net/forecast/" + darkSkyKey + "/" + address1.getLatitude() + "," + address1.getLongitude();
                    URL obj = new URL(forecastURL);
                    HttpURLConnection connection = (HttpURLConnection) obj.openConnection();
                    connection.setUseCaches(false);
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("User-Agent","Mozilla/5.0");
                    connection.setConnectTimeout(5000);
                    //connection.connect();

                    System.out.println("Sending GET request to URL: " + forecastURL);
                    try{
                        int responseCode = connection.getResponseCode();
                    }catch(Exception E){
                        E.printStackTrace();
                    }


                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(connection.getInputStream()));

                    String inputLine;
                    StringBuffer response = new StringBuffer();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);

                    }
                    in.close();

                    String responseCode1 = response.toString();
                    System.out.println(" GET RESPONSE CODE: " + responseCode1);
                    String[] splitter = responseCode1.split(":");

                    String summary = splitter[6].split(",")[0];
                    String temp = splitter[12].substring(0,4);
                    String humid = splitter[15].substring(0,4);
                    String wind = splitter[17].substring(0,4);
                    String precip = splitter[10].split(",")[0];
                    System.out.println("Summary " + summary);
                    System.out.println("Temperature " + temp);
                    System.out.println("Humidity " + humid);
                    System.out.println("Wind " + wind);
                    System.out.println("Precipitation Probability: " + precip);
                    final TextView textViewToChange = (TextView) findViewById(R.id.text1);
                    textViewToChange.setText(
                            "Summary: " + summary + "\nTemperature: " + temp + "F" + "\nHumidity: " + humid + "\nWind: " + wind + "mph" + "\nPrecipitation Probability: " + precip + "%" );
                }catch(Exception E){
                }
            }
        });
        thread.start();


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

    }
}




