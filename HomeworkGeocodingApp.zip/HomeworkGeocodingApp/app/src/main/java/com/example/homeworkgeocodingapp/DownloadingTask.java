package com.example.homeworkgeocodingapp;

import android.location.Address;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

class downloadingTask extends AsyncTask<Void,Void,Void> {





    String darkSkyKey;
    String forecastURL;
    HttpURLConnection connection;
    static Address address1;
    protected Void doInBackground(Void... params){
        forecastURL = "https://api.darksky.net/forecast/" + darkSkyKey + "/" + address1.getLatitude() + "," + address1.getLongitude();
        try{
            URL obj = new URL(forecastURL);
            connection = (HttpURLConnection) obj.openConnection();
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; U; Android 1.6; en-us; GenericAndroidDevice) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1");
            connection.setConnectTimeout(5000);
        }catch(Exception E){

        }


        //connection.connect();

        System.out.println("Sending GET request to URL: " + forecastURL);
        try{
            int responseCode = connection.getResponseCode();
        }catch(Exception E){
            E.printStackTrace();
        }

        System.out.println("1111111");
        StringBuffer response = new StringBuffer();
        try{
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            System.out.println("1111111");
            String inputLine;
            response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
                System.out.println("222222");
            }
            in.close();
        }catch(Exception E){

        }
        System.out.println("3333333");
        String responseCode1 = response.toString();
        System.out.println(" GET RESPONSE CODE: " + responseCode1);
        return null;
    }
    public static void setter(Address addressSet){
        address1 = addressSet;
    }
}
